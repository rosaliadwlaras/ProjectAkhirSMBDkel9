
<?php
$db_host = '152.67.198.76';
$db_name = 'DB220441100091';
$db_username = '220441100091';
$db_password = 'Pw@22091';
$mysqli = mysqli_connect($db_host, $db_username, $db_password,$db_name);
